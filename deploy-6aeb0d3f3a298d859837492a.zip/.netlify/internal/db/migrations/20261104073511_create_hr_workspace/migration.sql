CREATE TABLE "attendance" (
	"id" serial PRIMARY KEY,
	"owner_id" text NOT NULL,
	"employee_id" integer NOT NULL,
	"day" date NOT NULL,
	"status" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "employees" (
	"id" serial PRIMARY KEY,
	"owner_id" text NOT NULL,
	"name" text NOT NULL,
	"email" text NOT NULL,
	"phone" text DEFAULT '' NOT NULL,
	"department" text NOT NULL,
	"designation" text NOT NULL,
	"branch" text DEFAULT '' NOT NULL,
	"salary" integer DEFAULT 0 NOT NULL,
	"joined" date NOT NULL,
	"status" text DEFAULT 'Active' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payroll" (
	"id" serial PRIMARY KEY,
	"owner_id" text NOT NULL,
	"employee_id" integer NOT NULL,
	"month" text NOT NULL,
	"name" text NOT NULL,
	"amount" integer NOT NULL,
	"status" text DEFAULT 'Draft' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "hr_records" (
	"id" serial PRIMARY KEY,
	"owner_id" text NOT NULL,
	"kind" text NOT NULL,
	"data" jsonb NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "attendance_employee_day" ON "attendance" ("employee_id","day");--> statement-breakpoint
CREATE UNIQUE INDEX "employee_owner_email" ON "employees" ("owner_id","email");--> statement-breakpoint
CREATE UNIQUE INDEX "payroll_employee_month" ON "payroll" ("employee_id","month");--> statement-breakpoint
ALTER TABLE "attendance" ADD CONSTRAINT "attendance_employee_id_employees_id_fkey" FOREIGN KEY ("employee_id") REFERENCES "employees"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "payroll" ADD CONSTRAINT "payroll_employee_id_employees_id_fkey" FOREIGN KEY ("employee_id") REFERENCES "employees"("id") ON DELETE CASCADE;