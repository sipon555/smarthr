ALTER TABLE "company_members" ADD COLUMN "employee_id" integer;--> statement-breakpoint
ALTER TABLE "company_members" ADD CONSTRAINT "company_members_employee_id_key" UNIQUE("employee_id");--> statement-breakpoint
ALTER TABLE "company_members" ADD CONSTRAINT "company_members_employee_id_employees_id_fkey" FOREIGN KEY ("employee_id") REFERENCES "employees"("id") ON DELETE SET NULL;